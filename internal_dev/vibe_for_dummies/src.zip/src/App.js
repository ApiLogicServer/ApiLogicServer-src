import { createTheme, ThemeProvider } from '@mui/material/styles';
import * as React from "react";
// import { Admin, Resource, LisjsonapiProvidert, Datagrid, TextField, NumberField, DateField, Edit, SimpleForm, TextInput, NumberInput, DateInput, Show, SimpleShowLayout, EditButton, ShowButton } from "react-admin";
import { Admin, Resource, List, Datagrid, TextField, NumberField, DateField, Edit, SimpleForm, TextInput, NumberInput, DateInput, Show, SimpleShowLayout, EditButton, ShowButton } from "react-admin";
// import jsonapiProvider from "ra-data-jsonapi";
// import { createTheme, ThemeProvider } from '@mui/material/styles';
// import jsonServerProvider from "ra-data-json-server";
// const dataProvider = jsonServerProvider("http://localhost:5656/api/");
// import jsonServerProvider from "ra-data-json-server";
// const dataProvider = jsonServerProvider("http://localhost:5656/api/");
import jsonapiClient from "ra-jsonapi-client";
const dataProvider = jsonapiClient("http://localhost:5656/api/");

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: '#1976d2' },
    secondary: { main: '#9c27b0' },
  },
  typography: {
    fontFamily: [
      'Roboto',
      'Helvetica Neue',
      'Arial',
      'sans-serif'
    ].join(','),
  },
});

// --- Customer ---
const CustomerList = props => (
  <List {...props}>
    <Datagrid>
      <TextField source="id" />
      <TextField source="name" />
      <NumberField source="credit_limit" />
      <TextField source="email" />
      <EditButton />
      <ShowButton />
    </Datagrid>
  </List>
);

const CustomerEdit = props => (
  <Edit {...props}>
    <SimpleForm>
      <TextInput source="name" />
      <NumberInput source="credit_limit" />
      <TextInput source="email" />
    </SimpleForm>
  </Edit>
);

const CustomerShow = props => (
  <Show {...props}>
    <SimpleShowLayout>
      <TextField source="id" />
      <TextField source="name" />
      <NumberField source="credit_limit" />
      <TextField source="email" />
    </SimpleShowLayout>
  </Show>
);

// --- Order ---
const OrderList = props => (
  <List {...props}>
    <Datagrid>
      <TextField source="id" />
      <DateField source="CreatedOn" />
      <DateField source="date_shipped" />
      <NumberField source="amount" />
      <TextField source="customer_id" />
      <EditButton />
      <ShowButton />
    </Datagrid>
  </List>
);

const OrderEdit = props => (
  <Edit {...props}>
    <SimpleForm>
      <DateInput source="CreatedOn" />
      <DateInput source="date_shipped" />
      <NumberInput source="amount" />
      <TextInput source="customer_id" />
    </SimpleForm>
  </Edit>
);

const OrderShow = props => (
  <Show {...props}>
    <SimpleShowLayout>
      <TextField source="id" />
      <DateField source="CreatedOn" />
      <DateField source="date_shipped" />
      <NumberField source="amount" />
      <TextField source="customer_id" />
    </SimpleShowLayout>
  </Show>
);

// --- Product ---
const ProductList = props => (
  <List {...props}>
    <Datagrid>
      <TextField source="id" />
      <TextField source="name" />
      <NumberField source="price" />
      <EditButton />
      <ShowButton />
    </Datagrid>
  </List>
);

const ProductEdit = props => (
  <Edit {...props}>
    <SimpleForm>
      <TextInput source="name" />
      <NumberInput source="price" />
    </SimpleForm>
  </Edit>
);

const ProductShow = props => (
  <Show {...props}>
    <SimpleShowLayout>
      <TextField source="id" />
      <TextField source="name" />
      <NumberField source="price" />
    </SimpleShowLayout>
  </Show>
);

function App() {
  return (
    <ThemeProvider theme={theme}>
      <Admin dataProvider={dataProvider}>
        <Resource name="Customer" list={CustomerList} edit={CustomerEdit} show={CustomerShow} />
        <Resource name="Order" list={OrderList} edit={OrderEdit} show={OrderShow} />
        <Resource name="Product" list={ProductList} edit={ProductEdit} show={ProductShow} />
      </Admin>
    </ThemeProvider>
  );
}

export default App;