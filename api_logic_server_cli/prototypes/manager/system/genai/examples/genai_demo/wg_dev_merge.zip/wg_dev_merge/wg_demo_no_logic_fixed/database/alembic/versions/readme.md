Python scripts for database migrations, for use by alembic.
