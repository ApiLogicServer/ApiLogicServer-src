Alter kafka.consumer as required to define topic handlers.

To see a Sample Integration, [click here](https://apilogicserver.github.io/Docs/Sample-Integration/).