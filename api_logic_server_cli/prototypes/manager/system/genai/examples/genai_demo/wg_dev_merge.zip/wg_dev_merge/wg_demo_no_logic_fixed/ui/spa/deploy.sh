tar --exclude='node_modules' -czvf ../simple-spa.tgz .
scp -r ../simplerchive-spa.tgz  azureuser@apifabric.ai:simple-spa


