## GenAI Notes

Review the [database diagram](https://apilogicserver.github.io/Docs/Database-Diagram/).

GenAI work files (exact prompts, with inserts) saved for iterations, diagnostics
See [WebGenAI-CLI](https://apilogicserver.github.io/Docs/WebGenAI-CLI/). 