# SPA AI Dev

## Backend

SPA API definitions can be found in webgenai `project_override/database/spa_models/spa_page.py`

### Components

Component creation endpoint example: `http://localhost:8282/01JCN9J4EZ46NHX8KX2J3R6W80/SPAComponent`.  
Send a "prompt" in the attributes with the natural language description.

