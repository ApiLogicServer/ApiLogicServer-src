Compare these 2 examples.

Observe that correct logic creation requires explicit derived attributes.