This report combines:
* Behave log (lists Features, test Scenarios, results), with embedded
* Logic showing rules executed, and how they operated

