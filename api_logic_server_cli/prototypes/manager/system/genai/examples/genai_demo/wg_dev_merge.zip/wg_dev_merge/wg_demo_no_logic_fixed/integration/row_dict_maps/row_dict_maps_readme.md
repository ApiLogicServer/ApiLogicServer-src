Create definitions here to configure mappings for row <-> dicts, typically for application integration.

To see a Sample Integration, [click here](https://apilogicserver.github.io/Docs/Sample-Integration/).